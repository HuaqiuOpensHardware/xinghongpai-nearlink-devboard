#ifndef _WIFI_STA_H
#define _WIFI_STA_H

#include "errcode.h"

errcode_t func_wifi_sta_enable
    (
    void
    );

errcode_t func_wifi_sta_disable
    (
    void
    );

#endif
