
#ifndef _FAN_DEMO_H
#define _FAN_DEMO_H

#include "gpio.h"
#include "pinctrl.h"

#define PIN_FORWARD     GPIO_07
#define PIN_BACKWARD    GPIO_05

void func_fan_init
    (
    void
    );

void func_fan_forward
    (
    void
    );

void func_fan_backward
    (
    void
    );

#endif
