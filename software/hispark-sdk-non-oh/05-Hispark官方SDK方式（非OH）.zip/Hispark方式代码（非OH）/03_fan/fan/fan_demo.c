#include "fan_demo.h"


void func_fan_init
    (
    void
    )
{
    uapi_pin_set_mode(PIN_FORWARD, HAL_PIO_FUNC_GPIO);
    uapi_gpio_set_dir(PIN_FORWARD, GPIO_DIRECTION_OUTPUT);
    uapi_gpio_set_val(PIN_FORWARD, GPIO_LEVEL_LOW);

    uapi_pin_set_mode(PIN_BACKWARD, PIN_MODE_4);
    uapi_gpio_set_dir(PIN_BACKWARD, GPIO_DIRECTION_OUTPUT);
    uapi_gpio_set_val(PIN_BACKWARD, GPIO_LEVEL_LOW);
}

void func_fan_forward
    (
    void
    )
{
    uapi_gpio_set_val(PIN_FORWARD, GPIO_LEVEL_HIGH);
    uapi_gpio_set_val(PIN_BACKWARD, GPIO_LEVEL_LOW);
}

void func_fan_backward
    (
    void
    )
{
    uapi_gpio_set_val(PIN_FORWARD, GPIO_LEVEL_LOW);
    uapi_gpio_set_val(PIN_BACKWARD, GPIO_LEVEL_HIGH);
}