#include "led_demo.h"

#include "gpio.h"
#include "pinctrl.h"


void func_led_init
    (
    void
    )
{
    uapi_pin_set_mode(PIN_WORK_LED, HAL_PIO_FUNC_GPIO);
    uapi_gpio_set_dir(PIN_WORK_LED, GPIO_DIRECTION_OUTPUT);
    uapi_gpio_set_val(PIN_WORK_LED, GPIO_LEVEL_LOW);
}

void func_led_toggle
    (
    void
    )
{
    uapi_gpio_toggle(PIN_WORK_LED);
}