
#ifndef _LED_DEMO_H
#define _LED_DEMO_H

#define PIN_WORK_LED 14

void func_led_init
    (
    void
    );

void func_led_toggle
    (
    void
    );

#endif
