/**
 * Copyright (c) HiSilicon (Shanghai) Technologies Co., Ltd. 2023-2023. All rights reserved.
 *
 * Description: ADC Sample Source. \n
 *
 * History: \n
 * 2023-07-06, Create file. \n
 */
#include <stdio.h>
#include "app_init.h"
#include "common_def.h"

#include "osal_task.h"
#include "gpio.h"
#include "pinctrl.h"
#include "systick.h"
#include "watchdog.h"

#include "./traffic_light/traffic_light.h"
#include "./key/key_demo.h"
#include "./segment_display/segment_display.h"

#define SEGMENT_THREAD_STACK_SIZE      0x1000
#define SEGMENT_THREAD_PRIO            18

static void *segment_thread(const char *arg)
{
    unused(arg);

    // 配置数码管引脚
    segment_display_config_t segment_display_config = {
        .seg_a = GPIO_11,
        .seg_b = GPIO_01,
        .seg_c = GPIO_06,
        .seg_d = GPIO_03,
        .seg_e = GPIO_14,
        .seg_f = GPIO_12,
        .seg_g = GPIO_07,
        .seg_dp = GPIO_10,
        .digit1 = GPIO_04,  // 十位
        .digit2 = GPIO_02   // 个位
    };
    // 初始化数码管
    func_segment_display_init(&segment_display_config);
    func_segment_display_show_number(17);

    uapi_systick_init();

    while (1)
    {
        func_segment_display_process(2);
        uapi_systick_delay_ms(2);
    }
    return NULL;
}

#define TEST_THREAD_STACK_SIZE      0x1000
#define TEST_THREAD_PRIO            17

static void *test_thread(const char *arg)
{
    unused(arg);

    printf("08_traffic\r\n");

    // 配置交通灯
    traffic_light_config_t traffic_ligtht_config = {
        .red_pin = GPIO_08,
        .yellow_pin = GPIO_07,
        .green_pin = GPIO_05
    };
    func_traffic_light_init(&traffic_ligtht_config);

    key_config_t key_config = {
        .pin = GPIO_00,
        .active_level = GPIO_LEVEL_LOW, // 低电平有效
        .debounce_time = 20,            // 20ms消抖
    };
    func_key_register(&key_config);

    osal_kthread_lock();
    osal_task *segment_handle = NULL;
    segment_handle = osal_kthread_create((osal_kthread_handler)segment_thread, 0, "segment_thread", SEGMENT_THREAD_STACK_SIZE);
    if (segment_handle != NULL)
    {
        osal_kthread_set_priority(segment_handle, SEGMENT_THREAD_PRIO);
    }
    osal_kthread_unlock();

    uint16_t count_watchdog = 0;

    while (1)
    {
        func_key_process(10);
        osal_msleep(10);

        // 检查按键事件
        key_event_t event = func_key_get_event(GPIO_00);

        if (event == KEY_EVENT_PRESS)
        {
            printf("key pressed\r\n");
            func_traffic_light_set_all(true, true, true);
        } 
        else if (event == KEY_EVENT_RELEASE) 
        {
            printf("key released\r\n");
            func_traffic_light_off();
        }

        count_watchdog++;
        if (count_watchdog >= 100)
        {
            uapi_watchdog_kick(); 
        }
    }
    
    return NULL;
}


static void test_entry(void)
{
    osal_task *test_handle = NULL;
    osal_kthread_lock();
    test_handle = osal_kthread_create((osal_kthread_handler)test_thread, 0, "test_thread", TEST_THREAD_STACK_SIZE);
    if (test_handle != NULL)
    {
        osal_kthread_set_priority(test_handle, TEST_THREAD_PRIO);
    }
    osal_kthread_unlock();
}

app_run(test_entry);
