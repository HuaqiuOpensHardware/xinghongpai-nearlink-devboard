/**
 * Copyright (c) HiSilicon (Shanghai) Technologies Co., Ltd. 2023-2023. All rights reserved.
 *
 * Description: ADC Sample Source. \n
 *
 * History: \n
 * 2023-07-06, Create file. \n
 */
#include <stdio.h>
#include "app_init.h"
#include "common_def.h"

#include "osal_task.h"
#include "gpio.h"
#include "pinctrl.h"
#include "tcxo.h"

#include "./key/key_demo.h"

#define TEST_THREAD_STACK_SIZE      0x1000
#define TEST_THREAD_PRIO            17

static void *test_thread(const char *arg)
{
    unused(arg);

    printf("02_button\r\n");

    uapi_tcxo_init();

    func_key_init();

    key_config_t key_config = {
        .pin = GPIO_02,
        .active_level = GPIO_LEVEL_LOW, // 低电平有效
        .debounce_time = 20,            // 20ms消抖
    };
    func_key_register(&key_config);
    
    while (1)
    {   
        // 主循环中处理按键，假设每10ms调用一次
        func_key_process(10);
        
        // 检查按键事件
        key_event_t event = func_key_get_event(GPIO_02);

        if (event == KEY_EVENT_PRESS)
        {
            printf("key pressed\r\n");
        } 
        else if (event == KEY_EVENT_RELEASE) 
        {
            printf("key released\r\n");
        }
        
        osal_msleep(10);
    }
    
    return NULL;
}


static void test_entry(void)
{
    osal_task *test_handle = NULL;
    osal_kthread_lock();
    test_handle = osal_kthread_create((osal_kthread_handler)test_thread, 0, "test_thread", TEST_THREAD_STACK_SIZE);
    if (test_handle != NULL)
    {
        osal_kthread_set_priority(test_handle, TEST_THREAD_PRIO);
    }
    osal_kthread_unlock();
}

app_run(test_entry);
