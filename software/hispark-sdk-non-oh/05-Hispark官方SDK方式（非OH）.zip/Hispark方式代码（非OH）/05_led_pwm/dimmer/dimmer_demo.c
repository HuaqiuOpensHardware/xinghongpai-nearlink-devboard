#include "dimmer_demo.h"

// 调光器状态
static struct {
    uint8_t         group_id;           // PWM组
    pwm_channel_t   channel;            // PWM通道
    uint32_t        period_ns;          // PWM周期(纳秒)
    uint8_t         current_brightness; // 当前亮度百分比
    bool            is_on;              // 是否开启
} dimmer = {
    .channel = 0,
    .period_ns = 0,
    .current_brightness = 0,
    .is_on = false
};

errcode_t func_dimmer_init
    (
    uint8_t         group_id,
    pwm_channel_t   channel, 
    pin_t           pin, 
    pin_mode_t      pin_mode, 
    uint32_t        period_ns
    )
{
    // 保存配置
    dimmer.group_id = group_id;
    dimmer.channel = channel;
    dimmer.period_ns = period_ns;

    // 设置引脚模式
    uapi_pin_set_mode(pin, pin_mode);

    uapi_pwm_deinit();
    uapi_pwm_init();

    // 配置初始PWM参数（全低）
    pwm_config_t init_cfg = {
        .low_time = period_ns,  // 初始全低
        .high_time = 0,
        .offset_time = 0,
        .cycles = 0,
        .repeat = true
    };

    // 打开PWM通道
    errcode_t ret = uapi_pwm_open(channel, &init_cfg);
    if (ret != ERRCODE_SUCC)
    {
        printf("uapi_pwm_open() fail\r\n");
        uapi_pwm_deinit();
        return ret;
    }

    uapi_pwm_set_group(group_id, &channel, 1);
    uapi_pwm_start_group(group_id);
    
    // 初始状态关闭
    dimmer.is_on = false;
    dimmer.current_brightness = 0;
    
    return ERRCODE_SUCC;
}

errcode_t func_pwm_dimmer_set_brightness
    (
    uint8_t brightness
    ) 
{
    if (brightness > 100) 
    {
        brightness = 100;
    }
    
    dimmer.current_brightness = brightness;
    
    // 计算占空比（线性映射）
    uint32_t duty_ns = (brightness * dimmer.period_ns) / 100;
    
    // 配置PWM参数
    pwm_config_t cfg = {
        .low_time = dimmer.period_ns - duty_ns,  // 低电平时间
        .high_time = duty_ns,                    // 高电平时间
        .offset_time = 0,
        .cycles = 0,
        .repeat = true
    };

    uapi_pwm_close(dimmer.channel);
    uapi_pwm_deinit();
    uapi_pwm_init();

    // 打开PWM通道
    errcode_t ret = uapi_pwm_open(dimmer.channel, &cfg);
    if (ret != ERRCODE_SUCC)
    {
        uapi_pwm_deinit();
        return ret;
    }

    uapi_pwm_set_group(dimmer.group_id, &(dimmer.channel), 1);
    uapi_pwm_start_group(dimmer.group_id);
    
    return ERRCODE_SUCC;
}

uint8_t func_pwm_dimmer_get_brightness
    (
    void
    ) 
{
    return dimmer.current_brightness;
}

errcode_t func_pwm_dimmer_on
    (
    void
    ) 
{
    dimmer.is_on = true;
    return func_pwm_dimmer_set_brightness(dimmer.current_brightness);
}

errcode_t func_pwm_dimmer_off
    (
    void
    )
{
    dimmer.is_on = false;
    
    // 保存当前亮度
    uint8_t saved_brightness = dimmer.current_brightness;
    
    // 设置为0亮度
    errcode_t ret = func_pwm_dimmer_set_brightness(0);
    
    // 恢复保存的亮度（但不应用）
    dimmer.current_brightness = saved_brightness;
    
    return ret;
}