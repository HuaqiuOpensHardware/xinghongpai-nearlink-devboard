#ifndef _DIMMER_DEMO_H
#define _DIMMER_DEMO_H

#include "gpio.h"
#include "pinctrl.h"
#include "pwm.h"
#include "pwm_porting.h"


/**
 * @brief 初始化PWM调光器
 * @param group_id PWM组
 * @param channel PWM通道
 * @param pin PWM输出引脚
 * @param pin_mode 引脚模式
 * @param period_ns PWM周期(纳秒)
 * @retval ERRCODE_SUCC 成功
 * @retval 其他错误码 失败
 */
errcode_t func_dimmer_init
    (
    uint8_t         group_id,
    pwm_channel_t   channel, 
    pin_t           pin, 
    pin_mode_t      pin_mode, 
    uint32_t        period_ns
    );

/**
 * @brief 设置亮度
 * @param brightness 亮度百分比(0-100)
 * @retval ERRCODE_SUCC 成功
 * @retval 其他错误码 失败
 */
errcode_t func_pwm_dimmer_set_brightness
    (
    uint8_t brightness
    );

/**
 * @brief 获取当前亮度
 * @return 当前亮度百分比(0-100)
 */
uint8_t func_pwm_dimmer_get_brightness
    (
    void
    );

/**
 * @brief 开启调光器
 * @retval ERRCODE_SUCC 成功
 * @retval 其他错误码 失败
 */
errcode_t func_pwm_dimmer_on
    (
    void
    );

/**
 * @brief 关闭调光器
 * @retval ERRCODE_SUCC 成功
 * @retval 其他错误码 失败
 */
errcode_t func_pwm_dimmer_off
    (
    void
    );

#endif // PWM_DIMMER_H