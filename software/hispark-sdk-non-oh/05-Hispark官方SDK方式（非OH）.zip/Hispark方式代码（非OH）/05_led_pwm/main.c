/**
 * Copyright (c) HiSilicon (Shanghai) Technologies Co., Ltd. 2023-2023. All rights reserved.
 *
 * Description: ADC Sample Source. \n
 *
 * History: \n
 * 2023-07-06, Create file. \n
 */
#include <stdio.h>
#include "app_init.h"
#include "common_def.h"

#include "osal_task.h"
#include "gpio.h"
#include "pinctrl.h"

#include "./dimmer/dimmer_demo.h"

#define TEST_THREAD_STACK_SIZE      0x1000
#define TEST_THREAD_PRIO            17

static void *test_thread(const char *arg)
{
    unused(arg);

    printf("05_led_pwm\r\n");

    uapi_pin_init();
    uapi_gpio_init();
    uapi_pin_set_mode(GPIO_02, PIN_MODE_0);
    uapi_gpio_set_dir(GPIO_02, GPIO_DIRECTION_OUTPUT);
    uapi_gpio_set_val(GPIO_02, GPIO_LEVEL_HIGH);


    // // 初始化PWM调光器
    // errcode_t ret = func_dimmer_init(PWM_GROUP_0, PWM_2, GPIO_02, PIN_MODE_1, 40000);
    // if (ret != ERRCODE_SUCC)
    // {
    //     printf("PWM dimmer init failed: %d\n", ret);
    //     return NULL;
    // }
    
    while (1)
    {
        printf("hello world\r\n");

        // // 开启调光器
        // func_pwm_dimmer_on();
        
        // // 设置不同亮度
        // func_pwm_dimmer_set_brightness(25);  // 25%亮度
        // osal_msleep(2000);
        
        // func_pwm_dimmer_set_brightness(50);  // 50%亮度
        // osal_msleep(2000);
        
        // func_pwm_dimmer_set_brightness(75);  // 75%亮度
        // osal_msleep(2000);
        
        // func_pwm_dimmer_set_brightness(100); // 100%亮度
        osal_msleep(2000);
        
        // // 关闭调光器
        // func_pwm_dimmer_off();
    }
    
    return NULL;
}


static void test_entry(void)
{
    osal_task *test_handle = NULL;
    osal_kthread_lock();
    test_handle = osal_kthread_create((osal_kthread_handler)test_thread, 0, "test_thread", TEST_THREAD_STACK_SIZE);
    if (test_handle != NULL)
    {
        osal_kthread_set_priority(test_handle, TEST_THREAD_PRIO);
    }
    osal_kthread_unlock();
}

app_run(test_entry);
