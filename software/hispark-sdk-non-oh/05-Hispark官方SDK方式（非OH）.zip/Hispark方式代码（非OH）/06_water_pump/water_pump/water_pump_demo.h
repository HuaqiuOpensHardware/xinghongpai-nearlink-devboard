
#ifndef _WATER_PUMP_DEMO_H
#define _WATER_PUMP_DEMO_H

#include "gpio.h"
#include "pinctrl.h"

#define PIN 7

void func_water_pump_init
    (
    void
    );

errcode_t func_water_pump_on
    (
    void
    );

errcode_t func_water_pump_off
    (
    void
    );

#endif
