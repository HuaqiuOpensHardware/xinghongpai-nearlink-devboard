#include "water_pump_demo.h"


void func_water_pump_init
    (
    void
    )
{
    uapi_pin_set_mode(PIN, HAL_PIO_FUNC_GPIO);
    uapi_gpio_set_dir(PIN, GPIO_DIRECTION_OUTPUT);
    uapi_gpio_set_val(PIN, GPIO_LEVEL_HIGH);
}

errcode_t func_water_pump_on
    (
    void
    )
{
    return uapi_gpio_set_val(PIN, GPIO_LEVEL_LOW);
}

errcode_t func_water_pump_off
    (
    void
    )
{
    return uapi_gpio_set_val(PIN, GPIO_LEVEL_HIGH);
}
