/**
 * Copyright (c) HiSilicon (Shanghai) Technologies Co., Ltd. 2023-2023. All rights reserved.
 *
 * Description: ADC Sample Source. \n
 *
 * History: \n
 * 2023-07-06, Create file. \n
 */
#include <stdio.h>
#include "app_init.h"
#include "common_def.h"

#include "osal_task.h"
#include "gpio.h"
#include "pinctrl.h"

#define TEST_THREAD_STACK_SIZE      0x1000
#define TEST_THREAD_PRIO            17

static void *test_thread(const char *arg)
{
    unused(arg);

    printf("_test\r\n");
    
    while (1)
    {
        printf("hello world\r\n");
        osal_msleep(1000);
    }
    
    return NULL;
}


static void test_entry(void)
{
    osal_task *test_handle = NULL;
    osal_kthread_lock();
    test_handle = osal_kthread_create((osal_kthread_handler)test_thread, 0, "main_task", TEST_THREAD_STACK_SIZE);
    if (test_handle != NULL)
    {
        osal_kthread_set_priority(test_handle, TEST_THREAD_PRIO);
    }
    osal_kthread_unlock();
}

app_run(test_entry);
